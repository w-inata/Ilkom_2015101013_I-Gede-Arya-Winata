# nim_nama
evaluasi
